USE classicmodels;

-- 1. Kiểm tra trước khi tạo Index
EXPLAIN
SELECT *
FROM customers
WHERE customerName = 'Land of Toys Inc.';

-- 2. Tạo Index cho customerName
ALTER TABLE customers
ADD INDEX idx_customerName(customerName);

-- 3. Kiểm tra sau khi tạo Index
EXPLAIN
SELECT *
FROM customers
WHERE customerName = 'Land of Toys Inc.';

-- 4. Tạo Index ghép
ALTER TABLE customers
ADD INDEX idx_full_name(contactFirstName, contactLastName);

-- 5. Kiểm tra Index ghép
EXPLAIN
SELECT *
FROM customers
WHERE contactFirstName = 'Jean'
   OR contactFirstName = 'King';

-- 6. Xóa Index ghép
ALTER TABLE customers
DROP INDEX idx_full_name;

-- 7. Xem các Index hiện có
SHOW INDEX FROM customers;
