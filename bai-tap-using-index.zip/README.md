# Bài tập sử dụng Index

Thực hành tạo Index trên cơ sở dữ liệu `classicmodels` và sử dụng `EXPLAIN` để so sánh truy vấn trước và sau khi tạo Index.

## File
- `index.sql`: Toàn bộ câu lệnh SQL của bài tập.

## Cách chạy
1. Có database `classicmodels`.
2. Mở file `index.sql` bằng MySQL Workbench.
3. Chạy lần lượt các câu lệnh.
4. Quan sát kết quả EXPLAIN trước và sau khi tạo Index.
